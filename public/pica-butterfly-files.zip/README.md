# PICA Imperial

**Free STL. One-piece halves, no grinder, no storage, no caps. Print it, string it, throw it.**

A butterfly-profile responsive yoyo, sized to match the PICA lineup. Narrow
at the string gap, flares out to full width at the outer faces — not a
classic Imperial dome, which tapers the opposite way (wide at the gap,
narrow at the outer cap). Two solid halves join over a shoulder-screw axle
— screw head and nut sit visible on the outer face of each half. No
threads, no snap-fit caps, nothing to strip or pop off mid-throw.

---

## What's In This Folder

| Folder | Contents |
|--------|----------|
| `STL/` | `half_a.stl` (screw side), `half_b.stl` (nut side), `coupon.stl` (tolerance test) — print these. `assembly_REFERENCE_ONLY_do_not_print.stl` is both halves placed together, **reference only** |
| `STEP/` | Same four parts as STEP, for editing in any CAD tool |
| `Python/` | `_pica_imperial_shared.py`, `pica_imperial_half_a.py`, `pica_imperial_half_b.py`, `pica_imperial_assembly.py`, `pica_imperial_coupon.py` — [nurb](https://github.com/Shpigford/nurb) parametric source, live slider viewer included |
| `CAD_Renders/` | Preview renders of both halves and the full assembly |

---

## How to Print (in order)

| Step | File | Time | Weight |
|---|---|---|---|
| 1 | `coupon.stl` | ~20 min | ~6g |
| 2 | `half_a.stl` | ~60 min | ~21g (40% infill) / ~32g (60% infill) |
| 3 | `half_b.stl` | ~60 min | ~21g (40% infill) / ~32g (60% infill) |

Don't print `assembly_REFERENCE_ONLY_do_not_print.stl` — it's both halves
fused together for previewing the assembled shape, not a printable part.

## Print the Coupon First

`coupon.stl` is a flat, ~20-minute, ~6g test strip carrying the four fits
that actually bind or rattle if a printer's tolerances are off. No
orientation to think about — it prints flat, no supports. Station labels,
left to right:

| Label | Tests |
|---|---|
| **BRG** | Bearing pocket |
| **AXLE** | Axle bore |
| **SCR** | Screw head recess |
| **NUT** | Hex nut trap |

Before committing to the ~2hr full-half prints, run this once on a new
printer/filament combo:

1. Print `coupon.stl`
2. Press-fit the 608 bearing into the **BRG** pocket
3. Slide the shoulder screw through the **AXLE** bore
4. Seat the screw head in the **SCR** recess
5. Drop the M6 nut into the **NUT** trap

**Pass:** bearing seats snug (not loose, not forced), axle slides with no
wobble, screw head sits flush, nut drops in and doesn't spin. You're
dialed in — go print the halves.

**Fail:** bearing is loose or won't seat, axle wobbles or won't pass,
screw head sits proud of the surface, nut spins instead of dropping in.
Adjust that one dimension in `_pica_imperial_shared.py` (`BRG_SEAT_R`,
`AXLE_BORE`, `HEAD_D`/`HEAD_RECESS`, `NUT_AF`) and re-print just the
coupon — not the full half — until it passes.

This is why the source is parametric instead of a fixed mesh: a printer
running loose or tight on one fit is a slider change and a 20-minute
reprint, not a redesign.

---

## Design Specs

| Parameter | Value |
|-----------|-------|
| Diameter | 62 mm |
| Width (assembled) | 44 mm |
| Bearing | 608 (skateboard/fidget standard, 8×22×7mm) |
| Axle | 8mm ground shoulder screw, 20mm long, M6 tip |
| String gap | 7.2 mm (bearing width + 0.2mm float) |
| Response | Recess sized for flowable silicone (24mm ID × 26mm OD × 0.6mm deep) — not friction stickers |
| Rim edges | Filleted (2.5mm), no sharp edges |
| Branding | "PICA" / "TOYS" debossed on each outer face |

## Weight — Two Ways to Print It

The STL is modeled solid. Weight is entirely controlled by **infill %** in your
slicer — no CAD changes needed. Solid plastic (both halves, 100% infill) is
~105g; hardware adds ~14g (bearing ~6g, shoulder screw ~6g, M6 nut ~1.5g).

| | Infill | Plastic weight | + Hardware | **Assembled total** | Feel |
|---|---|---|---|---|---|
| **Lighter** | 40% | ~42g | ~14g | **~56g** | Fast, floaty, easier to throw for beginners |
| **Mid-tier (recommended)** | ~60% | ~63g | ~14g | **~77g** | Matches typical pro yoyo weight (65–80g), more stable spin |

Both are the same STL — pick your infill % in the slicer before printing. If
you're not sure, start at 60% for the more "normal yoyo" feel.

---

## Hardware Needed (BOM)

| Part | Spec | Qty | Notes |
|------|------|-----|-------|
| Bearing | 608 (8mm ID / 22mm OD / 7mm width) | 1 | Cheap skate/fidget bearings work fine |
| Shoulder screw | 8mm ground shoulder × 20mm, M6 tip | 1 | McMaster 91259A130 or equivalent |
| Hex nut | M6 standard | 1 | Captured in Half B's hex pocket |
| Response | Flowable silicone (yoyo response compound) | ~1 tube | Not friction stickers — recess is sized for silicone |
| String | Type 6/6 poly yoyo string | 1 | Any decent string works for testing |

**No shoulder screw on hand?** Use an M6×35mm bolt + nut instead — just
enlarge the axle bore to 3.3mm (M6 clearance) in the part file's `AXLE_BORE`
and re-run `nurb build`.

---

## Print Settings

| Setting | Value |
|---------|-------|
| Layer height | 0.2mm |
| Walls | 3+ |
| Infill | 40% (light, ~56g) or 60% (mid-tier, ~77g) — see table above |
| Material | PLA or PETG |
| Supports | Not required for most printers. One shallow ledge (the bearing seat, on the gap face) is a flat 90° overhang — it's the first thing your printer lays down, right on the bed, so it prints against the plate rather than bridging in air; most printers handle this fine at 0.2mm layers. If yours struggles, add a touch of support material or a brim around that recess |
| Orientation | Gap face (narrow side, bearing seat) down on the bed; outer face (branding side, screw/nut recess) up — this is how the STL exports by default, no rotation needed in your slicer |

---

## Assembly

### Option A: Responsive (with silicone response)

1. **Apply silicone response** (before assembly):
   - Get flowable silicone (yoyo response compound like YoYoFactory RTV, or flowable silicone from hardware store)
   - Fill each response recess on both halves completely
   - Use a credit card or plastic squeegee to wipe flat — remove excess, leave only what fills the recess
   - Let cure 24 hours per product instructions
   - Trim any overflow with a razor blade

2. **Assemble the yoyo**:
   - Press the 608 bearing into Half B's bearing seat (gap face)
   - Drop the M6 nut into the hex pocket on Half B's outer face — it's captured and can't spin once seated
   - Thread the shoulder screw through Half A from the outer face, through the bearing, into the captured nut in Half B
   - Tighten until the halves seat — the 20mm shoulder sets the gap, not your torque. Don't overtighten
   - String it. Throw it.

### Option B: Unresponsive (no silicone)

Skip the silicone step entirely. The yoyo becomes fully unresponsive — designed for advanced tricks and bind returns. Same assembly as above, minus the response compound.

---

## What This Is (and Isn't)

This is a free, simple, print-and-throw responsive yoyo — not a precision
competition part. It's a yoyo: forgiving geometry, generous tolerances, nothing
exotic. The design passed CAD dimensional/clearance checks and a printability
pass (wall thickness, fillets, overhangs); real-world PETG/PLA tolerances on
your printer are the only thing we can't check from here. If anything binds or
rattles, it's almost always a small clearance tweak, not a redesign — the
parametric source makes that a slider, not a rebuild.

No starburst response grooves, no unresponsive bearing variant — those are
possible future versions, not this one.

---

## License

**CC BY 4.0** — free to print, modify, and even sell. Just credit PICA TOYS.
See [LICENSE.md](LICENSE.md) for full terms.

*Built with [build123d](https://build123d.readthedocs.io) via
[nurb](https://github.com/Shpigford/nurb) — the parametric source in `Python/`
runs live with slider controls (`nurb dev`). Tag your prints `#PicaImperial`.*
