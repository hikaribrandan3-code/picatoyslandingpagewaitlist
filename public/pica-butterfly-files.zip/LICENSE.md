# License

**PICA Imperial** is licensed under **Creative Commons Attribution 4.0 International (CC BY 4.0)**.

You are free to:

- **Share** — copy and redistribute the material in any medium or format
- **Adapt** — remix, transform, and build upon the material
- **Commercial use** — sell prints, modify for your own products, use it however you want

Under the following terms:

- **Attribution** — You must give appropriate credit to **PICA TOYS**, provide a link
  to this repository or picatoys.com (if applicable), and indicate if changes were made.
  You may do so in any reasonable manner, but not in any way that suggests PICA TOYS
  endorses you or your use.

No additional restrictions — you may not apply legal terms or technological measures
that legally restrict others from doing anything the license permits.

Full legal text: https://creativecommons.org/licenses/by/4.0/legalcode

---

Copyright (c) 2026 PICA TOYS. Design files (STEP, STL, Python/build123d source)
are provided as-is, with no warranty of fitness for any particular purpose.
Print and use at your own risk.
